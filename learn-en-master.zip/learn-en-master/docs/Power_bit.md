# Power_bit
