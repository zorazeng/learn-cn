
## Our Goal  
---
In this study case, you are going to learn how to make your ring:bit car draw a circle.   

## Material Needed  
---
- 1 x [Ring:bit Car Kit](http://www.elecfreaks.com/estore/ring-bit-car-mirco-bit-educational-smart-robot-kit-for-kids.html)  
- 1 x [micro:bit](http://www.elecfreaks.com/estore/bbc-micro-bit-board-for-coding-programming.html)  
- 3 x AA Batteries  
- 1 x Pen  

## Assembly  
---
Please read our pamphlet within the package for the process of ring:bit car assembly. You have to prepare micro:bit and AA batteries by your own.   

Once you have completed assembling your car, bind the pen to the tail of your car using a rubber band.   

## Software  
---
[Microsoft MakeCode](https://makecode.microbit.org)  

## Programming  
---

For the whole program, please refer to the link here: [https://makecode.microbit.org/_VUcg0t2yKEfW](https://makecode.microbit.org/_VUcg0t2yKEfW)  

Or, you can download it directly by the website below.   

<div style="position:relative;height:0;padding-bottom:70%;overflow:hidden;"><iframe style="position:absolute;top:0;left:0;width:100%;height:100%;" src="https://makecode.microbit.org/#pub:_VUcg0t2yKEfW" frameborder="0" sandbox="allow-popups allow-forms allow-scripts allow-same-origin"></iframe></div>  


## Think  
---
How to make your ring:bit car run a square path? 


